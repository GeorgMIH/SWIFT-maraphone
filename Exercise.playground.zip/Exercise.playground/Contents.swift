//Don't change this code:
func calculator() {
    let a = 4 //First input xcode жаловался на force развертываание, чтобы не зависнуть просто скипнул
    let b = 3//Second input
  
  add(n1: a, n2: b)
  subtract(n1: a, n2: b)
  multiply(n1: a, n2: b)
  divide(n1: a, n2: b)
  
}

//Write your code below this line to make the above function calls work.

func add(n1: Int, n2: Int){
    print("Equal: \(n1 + n2)")
}

func subtract(n1: Int, n2: Int){
    print("Equal: \(n1 - n2)")
}

func multiply(n1: Int, n2: Int){
    print("Equal: \(n1 * n2)")
}

func divide(n1: Int, n2: Int){
    if n2 != 0{
        print("Equals: \(n1 / n2)")
    } else{
        print("Don't did like this")
    }
    
}

calculator()
