//Don't change this
var studentsAndScores = ["Amy": 99, "James": 11, "Helen": 34]

func highestScore(scores: [String: Int]) {
  
  //Write your code here.
    let a = studentsAndScores["Amy"]!
    let b = studentsAndScores["James"]!
    let c = studentsAndScores["Helen"]!
    
    var highestScoreStudent = 0
    
    if a > highestScoreStudent{
        highestScoreStudent = a
    } else if b > highestScoreStudent{
        highestScoreStudent = b
    } else{
        highestScoreStudent = b
    }
    
    print(highestScoreStudent)
}
